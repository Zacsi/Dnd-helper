import { Component } from '@angular/core';

@Component({
  selector: 'app-karakterek',
  templateUrl: './karakterek.component.html',
  styleUrls: ['./karakterek.component.scss']
})
export class KarakterekComponent {

}