export const environment = {
  firebase: {
    projectId: 'dnd-helper-2023',
    appId: '1:790082593347:web:cb2bc4940e0ee5fb0f2af6',
    storageBucket: 'dnd-helper-2023.appspot.com',
    apiKey: 'AIzaSyAImNPP9Ng7pRq48tqQWY4f-ixhH3ouQAg',
    authDomain: 'dnd-helper-2023.firebaseapp.com',
    messagingSenderId: '790082593347',
    measurementId: 'G-QRNY8YPMZ3',
  },
};